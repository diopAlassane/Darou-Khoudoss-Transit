<?php
$smtphost = "smtp.gmail.com"; // SMTP Host Name
$smtpuser = ''; // SMTP User Name
$smtppass = ''; // SMTP password
?>